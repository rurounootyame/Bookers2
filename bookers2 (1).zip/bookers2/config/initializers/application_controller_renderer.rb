# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '6b3c0fa48d6594fbbd0365396add981b3ac978e43cbed75e6ee92b323ce15a83f0b8846bc6db63cfb73c339097aae25b8631fded2c0b6e1ea229080ccf60c464'